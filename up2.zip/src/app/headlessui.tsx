"use client";

export {
  Transition,
  Dialog,
  Disclosure,
  Switch,
  Popover,
  RadioGroup,
  Tab,
  Combobox,
  Listbox,
  Menu,
  Portal,
  FocusTrap,
} from "@headlessui/react";
// export const {
//   Transition,
//   Dialog,
//   Disclosure,
//   Switch,
//   Popover,
//   RadioGroup,
//   Tab,
//   Combobox,
//   Listbox,
//   Menu,
//   Portal,
//   FocusTrap,
// } = Headeless;
