export const apiURL = "https://admin-panel.artexo.store/api/admin/"
// export const apiURL = "http://localhost:3001/api/admin/"